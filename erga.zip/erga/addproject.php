<?php
include_once 'includes/init.php';
include_once 'includes/functions.php';
include_once 'includes/timeout.php';
$message= add_project();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Erga & Ergasies</title>
        <?php
        include_once 'includes/head.php';
        ?>
    </head>
    <body>
        <?php include_once 'includes/menu.php';?>
        <div class="container"  style="width:300px">
            <!-- Content here -->
            <form method="POST">
                <div class="form-group">
                    <label>Project Name:</label>
                    <input type="text" name="projectname" class="form-control" placeholder="Project Name">
                </div>
                 <div class="form-group">
                    <label>Project type:</label>
                    <select class="form-control" name="projecttype">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="accountnumber">Account Number:</label>
                    <input type="text" name="accountnumber" class="form-control" placeholder="Account Number">
                </div>
                <div class="form-group">
                    <label>Number of posts:</label>
                    <input type="number" name="numberofposts" class="form-control" placeholder="Number of posts">
                </div>
                <div class="form-group">
                    <label>Start date:</label>
                    <input type="date" name="startdate" class="form-control" placeholder="Start date">
                </div>
                <div class="form-group">
                    <label>Description:</label>
                    <textarea type="date" name="description" class="form-control" placeholder="Description" rows="5"></textarea>
                </div>
                <input type="hidden" name="submitted" value="1">
                <button type="submit" class="btn btn-primary">Add Project</button>
            </form>
        </div>
        <p style="text-align:center; color:#c51244;font-weight: bold; font-size:16px;margin-left:40px;">
<?php echo $message; ?>
        </p>

    </body>
</html>
